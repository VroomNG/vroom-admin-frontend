import { Component, OnInit } from '@angular/core';
import Chart from 'chart.js';
import { chartService } from '../../service/chart.service';
import { Router, ActivatedRoute } from '@angular/router';
import { driverService } from '../../service/driver.service';
// core components
import { chartOptions, parseOptions } from "../../variables/charts";
import { LocationStrategy } from '@angular/common';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  dashboardList: any;
  public data: any;
  public salesChart;
  public clicked: boolean = true;
  public clicked1: boolean = false;
  primaryObject: any; primaryObject1: any;
  token: any;
  arrayValue: any = [];  arrayValue1: any = [];
  public pieChart;
  arrayKeys: any; arrayKeys1: any;
  backgroundColor: any;
  tempArray: any;
  SecondaryObject: any; SecondaryObject1: any;
  arrayValue2: any = [];  arrayValue2can: any = [];
  arrayKeys2: any; arrayKeys2can: any;
  tempArray2: any;
  arrayValue3: any;
  arrayKeys3: any;
  resultedData: any;
  PresentYear: number = new Date().getFullYear();


  constructor(
    private reportService: chartService,
    private location: LocationStrategy,
    private route: Router,
    private router: ActivatedRoute,
    private service: driverService,
  ) {


    history.pushState(null, null, window.location.href);
    this.location.onPopState(() => {
      history.pushState(null, null, window.location.href);
    });

    if (localStorage.token != "" || localStorage.token != undefined) {
      this.token = localStorage.token;
    }
    else {
      this.route.navigate(['/login']);
    }

  }

  ngOnInit() {
    this.getDashboard();
    this.driverReports(2021);
    this.tripReports(2021);
    this.getDRevenue(2021);
  }

  getDashboard() {
    // debugger;
    this.dashboardList = [];
    const inputRequest = {
      token: this.token
    };
    this.service.getDashboardList(inputRequest).subscribe((result: any) => {
      // debugger;
      this.dashboardList = [];
      if (result) {
        if (result.data) {
          // console.log("Dashboard RESULT ==>",result.data);
          this.dashboardList = result.data;
        }
      }
    });
  }

  driverReports(year) {
   debugger;
    const inputRequest = {
      token: this.token,     
      year:2021
    };
    
    this.arrayValue=[];
    this.arrayKeys=[];this.backgroundColor = []; this.tempArray=[];
    this.reportService.getDriverReportDetails(inputRequest).subscribe((result: any) => {
      if (result) {
        
        this.primaryObject = result.driver;
        this.primaryObject1 = result.rider;
       // this.arrayValue = Object.values(this.primaryObject[0]).filter((i: any) => i);
        Object.entries(this.primaryObject[0]).forEach(([key, value]) => {
          this.arrayValue.push(value);      
        });
        Object.entries(this.primaryObject1[0]).forEach(([key, value]) => {
          this.arrayValue1.push(value);      
        });

        this.arrayKeys = Object.keys(this.primaryObject[0]);
        this.arrayKeys1 = Object.keys(this.primaryObject1[0]);
        this.backgroundColor = [
          { color: '#5e72e4' }, { color: '#5603ad' }, { color: '#8965e0' }, { color: '#f3a4b5' }, { color: '#f5365c' }, { color: '#fb6340' }, { color: '#ffd600' }, { color: '#2dce89' }, { color: '#11cdef' }, { color: '#2bffc6' }, { color: '#32325d' }, { color: '#94685e' }
        ];
        this.tempArray = this.arrayKeys.map((item: any, i: any) => {
          return { name: item, color: this.backgroundColor[i].color, data: this.arrayValue[i] != null ? this.arrayValue[i] : 0 }
        })
        parseOptions(Chart, chartOptions());
               

        var chartSales = document.getElementById('chart-pie');
        this.pieChart = new Chart(chartSales, {
          type: 'line',
          options: {},
          data: {
            labels: this.arrayKeys,            
            datasets: [
              {
                label: "Driver",
                data: this.arrayValue,
                borderColor: 'rgb(243, 164, 181)',
                backgroundColor: 'rgba(255,0,0,0.3)',              
               radius:5
               // backgroundColor: ['#5e72e4', '#5603ad', '#8965e0', '#f3a4b5', '#f5365c', '#fb6340', '#ffd600', '#2dce89', '#11cdef', '#2bffc6', '#32325d', '#94685e']
              },
              {
                label: "Rider",
                data: this.arrayValue1,
                borderColor: 'rgb(94, 114, 228)',
                backgroundColor: 'rgb(17, 205, 239)',             
               radius:5 
               // backgroundColor: ['#5e72e4', '#5603ad', '#8965e0', '#f3a4b5', '#f5365c', '#fb6340', '#fb6340', '#2dce89', '#11cdef', '#2bffc6', '#32325d', '#94685e']
              }
            ]
          }
        });
     
      }
    })

  }

  //  rider reports
  tripReports(year) {
    debugger;
    const inputRequest = {
      token: this.token,     
      year:year
    };
    this.SecondaryObject = [];this.arrayValue2=[];this.arrayKeys2=[];
    this.reportService.getRiderReportDetails(inputRequest).subscribe((result: any) => {
      debugger;
      if (result) {        
        this.SecondaryObject = result.completed;
        this.SecondaryObject1 = result.cancelled;
        // this.arrayValue2 = Object.values(this.SecondaryObject[0]).filter((i: any) => i);       

       Object.entries(this.SecondaryObject[0]).forEach(([key, value]) => {
        this.arrayValue2.push(value);      
      });
      Object.entries(this.SecondaryObject1[0]).forEach(([key, value]) => {
        this.arrayValue2can.push(value);      
      });
    
        // console.log(this.arrayValue2, 'filtered value')
        this.arrayKeys2 = Object.keys(this.SecondaryObject[0]);
        this.arrayKeys2can = Object.keys(this.SecondaryObject1[0]);

        this.backgroundColor = [
          { color: '#5e72e4' }, { color: '#5603ad' }, { color: '#8965e0' }, { color: '#f3a4b5' }, { color: '#f5365c' }, { color: '#fb6340' }, { color: '#ffd600' }, { color: '#2dce89' }, { color: '#11cdef' }, { color: '#2bffc6' }, { color: '#32325d' }, { color: '#94685e' }
        ];
        this.tempArray2 = this.arrayKeys2.map((item: any, i: any) => {
          return { name: item, color: this.backgroundColor[i].color, data: this.arrayValue2[i] != null ? this.arrayValue2[i] : 0 }
        })
     
        parseOptions(Chart, chartOptions());

        var chartSales1 = document.getElementById('chart-pie2');
        this.pieChart = new Chart(chartSales1, {
          type: 'line',
          options: {
            onClick: (event, legendItem) => {
              debugger;
              console.log("This is working!");
            }
          },
          data: Chart.chartData = {
          // chartData: Chart.ChartData[] =[{
            labels: this.arrayKeys2,
            datasets: [
              {
                 label: "Completed",
                data: this.arrayValue2,
                // backgroundColor: ['#5e72e4', '#5603ad', '#8965e0', '#f3a4b5', '#f5365c', '#fb6340', '#ffd600', '#2dce89', '#11cdef', '#2bffc6', '#32325d', '#94685e']
                // backgroundColor: ['#5e72e4', '#5603ad', '#8965e0', '#f3a4b5', '#f5365c', '#fb6340', '#ffd600', '#2dce89', '#11cdef', '#2bffc6', '#32325d', '#94685e']
                borderColor: 'rgb(243, 164, 181)',
                backgroundColor: 'rgba(255,0,0,0.3)',              
               radius:5
              },
              {
                label: "Cancelled",
               data: this.arrayValue2can,
               // backgroundColor: ['#5e72e4', '#5603ad', '#8965e0', '#f3a4b5', '#f5365c', '#fb6340', '#ffd600', '#2dce89', '#11cdef', '#2bffc6', '#32325d', '#94685e']
               // backgroundColor: ['#5e72e4', '#5603ad', '#8965e0', '#f3a4b5', '#f5365c', '#fb6340', '#ffd600', '#2dce89', '#11cdef', '#2bffc6', '#32325d', '#94685e']
               borderColor: 'rgb(94, 114, 228)',
               backgroundColor: 'rgb(17, 205, 239)',             
              radius:5
             }
            ]
          }
          // {
          //   labels: this.arrayKeys2,
          //   datasets: [             
          //     {
          //       // label: "Cancelled",
          //       data: this.arrayValue2can,
          //       // backgroundColor: ['#5e72e4', '#5603ad', '#8965e0', '#f3a4b5', '#f5365c', '#fb6340', '#ffd600', '#2dce89', '#11cdef', '#2bffc6', '#32325d', '#94685e']
          //       // backgroundColor: ['#5e72e4', '#5603ad', '#8965e0', '#f3a4b5', '#f5365c', '#fb6340', '#5603ad', '#8965e0', '#11cdef', '#2bffc6', '#32325d', '#94685e']
          //       borderColor: '#11cdef',
         // backgroundColor: rgb(17, 205, 239),
          //       fill:false
          //     }
          //   ]
          // }
        // ]
        });

      }
    })
  }


  chartExample2 = {
    options: {
      scales: {
        xAxes: [{
          barThickness: 100,
          maxBarThickness: 40,
        }],
        yAxes: [
          {
            ticks: {
              callback: function (value) {
                if (!(value % 10)) {
                  //return '$' + value + 'k'
                  return value;
                }
              }
            }
          }
        ]
      },
      tooltips: {
        callbacks: {
          label: function (item, data) {
            var label = data.datasets[item.datasetIndex].label || "";
            var yLabel = item.yLabel;
            var content = "";
            if (data.datasets.length > 1) {
              content += label;
            }
            content += yLabel;
            return content;
          }
        }
      }
    },
    data: {
      labels: [],
      datasets: [
        {
          label: "Total Trip amount",
          data: []
        }
      ]
    }
  }


  // driver
  getDRevenue(val) {
    const inputRequest = {
      token: this.token,
      year:2021
    };

    this.reportService.getDriverRevenue(inputRequest).subscribe((result: any) => {
      this.resultedData = [];

      if (result) {
        console.log(result.data, "driver revenue");
        this.resultedData = result.data;
        // var x = this.resultedData.map((item)=> item.firstname + '' + item.lastname);
        // console.log(x, 'x- axis');
        // var y = this.resultedData.map((item)=> item.amount != null? item.amount: 0);
        // console.log(y, 'y- axis');
        var x = Object.keys(this.resultedData[0]);
        // var y = Object.values(this.chartView[0]);
        var y = Object.keys(this.resultedData[0]).map((item) => this.resultedData[0][item]);


        this.chartExample2.data.labels = x;
        this.chartExample2.data.datasets[0].data = y;

        var chartOrders = document.getElementById('Bar-Chart');
        var ordersChart = new Chart(chartOrders, {
          type: 'bar',
          options: this.chartExample2.options,
          data: this.chartExample2.data,
        });

      }

      // if (result.data) {
      //   this.chartView = result.data;
      //   // console.log('chart view ==>', this.chartView);
      //   var x = Object.keys(this.chartView[0]);
      //   // var y = Object.values(this.chartView[0]);
      //   var y = Object.keys(this.chartView[0]).map((item) => this.chartView[0][item]);
      //   this.chartExample2.data.labels = x;
      //   this.chartExample2.data.datasets[0].data = y;
      //   // console.log('data-x', y);
      //   // console.log('data-y', this.chartExample2.data.datasets[0].data);
      //   var chartOrders = document.getElementById('chart-orders');
      //   var ordersChart = new Chart(chartOrders, {
      //     type: 'bar',
      //     options: this.chartExample2.options,
      //     data: this.chartExample2.data,
      //   });

      // }





    })
  }

  selectedDropdown(i) {
    // debugger;
    var selYear = (<HTMLInputElement>document.getElementById("selYear"));
    var area = i.target.value;
    console.log('area of data', area)
    this.driverReports(i.target.value);
    // if(i.target.value === '2'){
    //   this.driverReports();
    // }
    // else{
    //   this.riderReports();
    // }
  }
  // selectedDropdownYear(i){
  //   // debugger;    
  //   var selUser = (<HTMLInputElement>document.getElementById("selUser"));

  //   var area = i.target.value;
  //   console.log('area of data', area)
  //   this.driverReports(i.target.value);
  // }

  selectedDropdownTrip(i) {
    // debugger;    
    var area = i.target.value;    
    this.tripReports(i.target.value);
    
  }
  // selectedDropdownTripYear(i){
  //   // debugger;    
  //   var selUser = (<HTMLInputElement>document.getElementById("tripStatus"));

  //   var area = i.target.value;
  //   console.log('area of data', area)
  //   this.tripReports(selUser.value,i.target.value);
  // }

  selectedDropdownRevenue(i) {   
    var area = i.target.value;   
    this.getDRevenue(i.target.value);
    
  }


  public chartClicked(e:any):void {
    console.log(e);
  }
 
  public chartHovered(e:any):void {
    console.log(e);
  }
}


